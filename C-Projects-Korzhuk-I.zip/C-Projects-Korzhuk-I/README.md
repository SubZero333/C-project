# C-Projects
C-Projects for Math package.

Korzhuk Andrew. Group 1. Project Quaternion. (Plain C)

